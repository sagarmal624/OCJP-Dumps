public class AssertionEnabling {

	public static void main(String[] args) {
		// int assert = 1; // nie skompiluje sie w 1.7
	}
	
}
