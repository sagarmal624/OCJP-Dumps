public class FormatTest {
	public static void main(String[] args) {
		 System.out.printf("%1$s %s %<s %s", "A", "B", "C", "D");
	}
}