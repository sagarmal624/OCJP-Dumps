import java.util.*;

public class DiamondTest {
	
	public static void main(String[] args) {
		List<Integer> lista = new ArrayList<>();
		
		lista = new LinkedList<>();
	}
}
