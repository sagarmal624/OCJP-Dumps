public class BirthDate {
	int year;
	
	public static void main(String[] args) {
		BirthDate birthDate = new BirthDate();
		birthDate.showYear();
	}
	
	public void showYear() {
		System.out.println("The year is " + year);
	}
}
