import java.util.Date;

public class TimeTravel {
	public static void main(String[] args) {
		int day;
		int year;
		System.out.println("You step into the portal");
		year = 2050;
		System.out.println("The year is " + year);
		
		//System.out.println("The day is " + day); �LE
		
		Date date;
		if (date == null) {
			System.out.println("date is null");
		}
	}
}
