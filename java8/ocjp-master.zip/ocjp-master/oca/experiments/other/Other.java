package other;
public class Other { public static String hello = "Hello"; }

class A {

	@Override
	public boolean equals(Object a) {
		return false;
	}
}
