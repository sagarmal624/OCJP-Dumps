import java.*;

import static java.lang.Integer.*;
import static java.lang.Long.*;
import static java.lang.System.out;

public class ImportTest {
	public static void main(String... args) {
		// out.println(MAX_VALUE); // BŁĄD - MAX_VALUE jest w Long i w Integer
	}
}

