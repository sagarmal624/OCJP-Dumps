public class CastingTest {
	public static void main(String[] args) {
		String a = (String)null;
	}
}

