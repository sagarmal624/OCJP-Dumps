class AClass {
	int y = 5;
	int x = y;
	public static void main(String[] args) {
		System.out.print(new Test().x);
		
		boolean b = true || false;
		
	}
}

