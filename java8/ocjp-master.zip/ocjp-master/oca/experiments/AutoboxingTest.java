public class AutoboxingTest {
	public static void main(String[] args) {
		Integer i = new Integer(5) + new Integer(6);
		System.out.println(i); // 11
	}
}

