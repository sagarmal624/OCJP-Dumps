public class FloatTest{
	public static void main(String[] args) {
		System.out.println(((float)5)/4);
		
		int i = 12345678;
		float f = i;
		System.out.println((int)f);
		
		System.out.println(5.5 % 3.5 + 3);

		Object[][] x = new Object[][] {new String[], {} };
		
		System.out.println( Integer.toBinaryString(~1) );
		
	}
}

