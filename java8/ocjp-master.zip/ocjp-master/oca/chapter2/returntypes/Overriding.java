class Alpha {
	Alpha doStuff(char c) {
		return new Alpha(); 
	}
}

class Beta extends Alpha {
	Beta doStuff(char c) {
		return new Beta();
	}
}
