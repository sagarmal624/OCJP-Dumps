class Foo {
	void go(){}
}

class Bar extends Foo {
	String go(int i) {
		return null;
	}
}