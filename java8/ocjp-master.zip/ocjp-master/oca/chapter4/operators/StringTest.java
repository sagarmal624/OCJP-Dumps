public class StringTest {
	public static void main(String[] args) {
		String a = "String";
		int b = 3;
		int c = 7;
		System.out.println(a + b + c);
	}		
}