public class CompareTest {
	public static void main(String[] args) {
		boolean b = 100 > 99;
		System.out.println(b);
		
		char c = 'c';
		// c = c + 1;
		c += 1;
		System.out.println(c);
	}
}
