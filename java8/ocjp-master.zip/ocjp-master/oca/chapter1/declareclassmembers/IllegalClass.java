public class IllegalClass {
	public abstract void doIt();
}
