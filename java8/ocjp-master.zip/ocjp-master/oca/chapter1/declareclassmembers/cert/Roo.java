package cert;

public class Roo {
	private String doRooThings() {
		return "fun";
	}
}
