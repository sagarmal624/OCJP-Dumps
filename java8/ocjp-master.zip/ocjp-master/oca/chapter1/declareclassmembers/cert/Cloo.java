package cert;

class Cloo extends Roo {
	public void testCloo() {
		System.out.println(doRooThings());
	}
}