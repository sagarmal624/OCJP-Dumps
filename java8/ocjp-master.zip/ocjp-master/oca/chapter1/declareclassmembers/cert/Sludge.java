package cert;

class Sludge {
	public void testIt() {
		System.out.println("sludge");
	}
}
