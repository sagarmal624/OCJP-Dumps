package cars;

public abstract class Car extends Vehicle {
	public abstract void goUpHill();
	public void doCarThings() {
		// special car code goes here
	}
}
