package cars;

public class Mini extends Car {
	public void goUpHill() {
		// Mini-specific going uphill code
	}
}
