package cars;

public abstract class Vehicle {
	private String type;
	public abstract void goUpHill();
	public String getType() {
		return type;
	}
}
