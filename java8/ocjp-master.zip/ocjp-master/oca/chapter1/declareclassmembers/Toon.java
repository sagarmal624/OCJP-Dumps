import notcert.Cloo;

class Toon {
	public static void main(String[] args) {
		Cloo c = new Cloo();
		System.out.println(c.doRooThings());
	}		
}