package book;

import cert.*;

class Goo {
	public static void main(String[] args) {
		Sludge o = new Sludge();
		o.testIt();
	}
}
