package notcert;

import cert.Roo;

public class Cloo extends Roo {
	public void testCloo() {
		System.out.println(this.doRooThings());
	}
	public static void main(String... args) {
		Cloo c = new Cloo();
		c.testCloo();
	}
}
