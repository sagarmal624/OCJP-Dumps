package certification;

public class Parent {
	int x = 9;
}