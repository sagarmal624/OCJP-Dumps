package certification;

public class OtherClass {
	void testIt() {
		System.out.println("Other class");
	}
}
