
class SuperClass {
	public final void showSample() {
		System.out.println("One thing.");
	}
}

class SubClass extends SuperClass {
	public void showSample() {
		System.out.println("Another thing.");
	}
}
