public interface Bounceable {
	public final static int BAR = 42;
	
	void bounce();
	void setBounceFactor(int bf);
}
