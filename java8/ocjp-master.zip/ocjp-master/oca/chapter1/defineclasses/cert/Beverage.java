package cert;

public final class Beverage {
	public void importantMethod() {
	}

	public static void main(String[] args) {
		System.out.println("Jestem w klasie Beverage");
	}
}
