package food;

public abstract class Fruit {
}
