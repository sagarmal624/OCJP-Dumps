import food.Fruit;

class Apple extends Fruit {
}
