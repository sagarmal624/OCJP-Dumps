import java.util.*;

public class MyClassWithImport {
	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<String>();
		TreeSet<String> t = new TreeSet<String>();
	}
}
