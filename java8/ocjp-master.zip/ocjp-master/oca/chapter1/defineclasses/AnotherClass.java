class AnotherClass {
	public static void main(String[] args) {
		// B��d - nie kompiluje si�
		// Car car = new Car();  
	}
}
