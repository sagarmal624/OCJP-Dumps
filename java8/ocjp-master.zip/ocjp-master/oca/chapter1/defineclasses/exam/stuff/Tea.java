package exam.stuff;

import cert.Beverage;

class Tea extends Beverage {
	public static void main(String[] args) {
		System.out.println("Jestem w klasie Tea");
	}
}
