package experiments;

import java.util.Collections;
import java.util.Set;

public class SortedSetTest {

    public static void main(String[] args) {
        Set<String> set = Collections.emptySortedSet();
        set.add("aA");
    }
}
