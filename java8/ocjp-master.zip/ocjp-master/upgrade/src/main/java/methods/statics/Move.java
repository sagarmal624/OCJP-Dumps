package methods.statics;

public interface Move {
    static int move() {
        return 4;
    }
}
