package methods.defaults;

public interface Run {
    public default int getSpeed() {
        return 10;
    }
}
