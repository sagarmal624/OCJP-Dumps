package lambdas;

public class Kangaroo extends Animal {
    public Kangaroo(String speciesName, boolean hopper, boolean swimmer) {
        super(speciesName, hopper, swimmer);
    }
}
