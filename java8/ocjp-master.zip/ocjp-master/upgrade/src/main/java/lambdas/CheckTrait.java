package lambdas;

interface CheckTrait {
    boolean test(Animal a);
}
