import food.Fruit;

class Apple extends Fruit {
  public static void main(String[] args) {
    Apple a = new Apple();
    System.out.println("Hello, fruits!");
  }
}
