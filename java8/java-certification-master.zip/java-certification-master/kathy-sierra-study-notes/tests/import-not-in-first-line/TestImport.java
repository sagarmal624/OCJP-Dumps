




import java.util.*;

class TestImport {
  public static void main(String[] args) {
    System.out.println("ola");
  }
}

/*
 * Test if the `import` statement must be in the first line or if
 * new lines are allowed before it.
 *
 * Result: new lines before the `import` are allowed.
