package exam.stuff;

import cert.Beverage;

class Tea extends Beverage {
  
}
