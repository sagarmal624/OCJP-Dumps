package cert;
class Beverage {
  
}
