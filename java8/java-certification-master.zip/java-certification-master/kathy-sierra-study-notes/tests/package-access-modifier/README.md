This will cause compilation fail. Example in the book.
