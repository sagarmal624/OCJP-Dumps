public class GetJar {
    public static void main(String[] args) {
        System.out.println(myApp.Foo.d);
    }
}
