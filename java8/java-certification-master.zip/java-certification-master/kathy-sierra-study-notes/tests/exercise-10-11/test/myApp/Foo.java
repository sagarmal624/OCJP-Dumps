package myApp;
public class Foo { public static int d = 8; }
