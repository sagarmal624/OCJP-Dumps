* It's possible to declare private or protected methods and attributes in abstract classes.
* It's forbidden to declare private abstract methods.
