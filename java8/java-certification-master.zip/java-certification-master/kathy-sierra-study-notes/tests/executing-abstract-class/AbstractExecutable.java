/*
 * Test that an abstract class can be executed.
 *
 * Result: success, it can be executed.
 */

abstract class AbstractExecutable {
  public static void main (String[] args) {
    System.out.println("Abstract classes can be executed");
  }
}
